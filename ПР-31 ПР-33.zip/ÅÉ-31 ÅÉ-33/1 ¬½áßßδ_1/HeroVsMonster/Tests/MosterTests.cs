using NUnit.Framework;
using HeroVsMonster.Classes;

namespace HeroVsMonster.Tests
{
    public class MonsterTests
    {
        Actor EvilTroll;
        Actor Rat;

        [SetUp]
        public void Setup()
        {
            EvilTroll = new Monster("���� �����", 200, 25);
            Rat = new Monster("�����", 3, 5);
        }

        [Test]
        public void EvilTroll_Has_Correct_Name()
        {
            string Expected = "���� �����";
            string Actual = EvilTroll.Name;
            Assert.AreEqual(Expected, Actual);
        }

        [Test]
        public void EvilTroll_Has_Correct_Damage()
        {
            int Expected = 25;
            int Actual = EvilTroll.Damage;
            Assert.AreEqual(Expected, Actual);
        }

        [Test]
        public void EvilTroll_Has_Correct_MaxHp()
        {
            int Expected = 200;
            int Actual = EvilTroll.MaximumHealth;
            Assert.AreEqual(Expected, Actual);
        }

        [Test]
        public void EvilTroll_Get_1_Damage()
        {
            EvilTroll.GetDamage(1);
            int ExpectedHp = 199;
            int ActualHp = EvilTroll.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void EvilTroll_Get_105_Damage()
        {
            EvilTroll.GetDamage(105);
            int ExpectedHp = 95;
            int ActualHp = EvilTroll.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void EvilTroll_Get_9999_Damage()
        {
            EvilTroll.GetDamage(9999);
            int ExpectedHp = 0;
            int ActualHp = EvilTroll.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void EvilTroll_Get_9999_Damage_And_Die()
        {
            EvilTroll.GetDamage(9999);
            Assert.IsTrue(EvilTroll.IsDead);
        }

        [Test]
        public void EvilTroll_Get_FullHp_Damage_And_Die()
        {
            EvilTroll.GetDamage(EvilTroll.MaximumHealth);
            Assert.IsTrue(EvilTroll.IsDead);
        }

        [Test]
        public void EvilTroll_FullHP_Potion()
        {
            EvilTroll.UsePotion();
            Assert.AreEqual(EvilTroll.Health, EvilTroll.MaximumHealth);
        }

        [Test]
        public void EvilTroll_Get_1_damage_and_use_Potion()
        {
            EvilTroll.GetDamage(1);
            EvilTroll.UsePotion();
            Assert.AreEqual(EvilTroll.MaximumHealth, EvilTroll.Health);
        }

        [Test]
        public void EvilTroll_Heals()
        {
            EvilTroll.GetDamage(100);
            EvilTroll.UsePotion();
            int ExpectedHp = 140;
            int ActualHp = EvilTroll.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void EvilTroll_Has_Only_One_Potion()
        {
            EvilTroll.GetDamage(100);
            EvilTroll.UsePotion();
            EvilTroll.UsePotion();
            EvilTroll.UsePotion();
            EvilTroll.UsePotion();
            EvilTroll.UsePotion();
            int ExpectedHp = 140;
            int ActualHp = EvilTroll.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void Rat_Uses_Potion_And_Restore_1HP()
        {
            Rat.GetDamage(2);
            Rat.UsePotion();
            int ExpectedHp = 2;
            int ActualHp = Rat.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void Dead_Monster_Cant_Use_Potion()
        {
            EvilTroll.GetDamage(200);
            EvilTroll.UsePotion();
            int ExpectedHp = 0;
            int ActualHp = EvilTroll.Health;
            Assert.AreEqual(ExpectedHp, ActualHp);
        }

        [Test]
        public void Monster_Cant_ressurect_by_using_Potion()
        {
            EvilTroll.GetDamage(200);
            EvilTroll.UsePotion();
            Assert.IsTrue(EvilTroll.IsDead);
        }


    }
}