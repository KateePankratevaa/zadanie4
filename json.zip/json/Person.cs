﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace rabota_s_json
{
    public class Person
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("surname")]
        public string Surname { get; set; }
        [JsonPropertyName("id")]
        public int PersonId { get; set; }
        [JsonPropertyName("activities")]
        public List<string> Activities { get; set; }
    }
}
