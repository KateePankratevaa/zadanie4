﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rabota_s_json
{
    public class Yes_No
    {
            public string answer { get; set; }
            public bool forced { get; set; }
            public string image { get; set; }
    }
}
