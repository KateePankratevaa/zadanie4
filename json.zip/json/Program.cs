﻿using rabota_s_json;
using System.Text.Json;
using System.Xml;

HttpClient client = new HttpClient();

var Valute = new List<Valute>();
XmlDocument doc = new XmlDocument();
doc.Load("data/valutes.xml");
var buf = doc.DocumentElement;
foreach (XmlNode val in buf)
{
    Valute valute = new Valute();
    valute.Name = val["Name"].InnerText;
    valute.Value = Convert.ToDouble(val["Value"].InnerText);
    valute.CharCode = val["CharCode"].InnerText;
    Valute.Add(valute);
}

var options = new JsonSerializerOptions
{
    Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    WriteIndented = true
};
Console.WriteLine(JsonSerializer.Serialize(Valute, options));

try
{
    HttpResponseMessage response = await client.GetAsync("https://yesno.wtf/api");
    response.EnsureSuccessStatusCode();
    string responseBody = await response.Content.ReadAsStringAsync();
    Console.WriteLine(responseBody);
    StreamWriter sr = File.CreateText("yes_no.json");
    sr.WriteLine(responseBody);
    sr.Close();
    var yes_no = new List<Yes_No>();
    Yes_No t = JsonSerializer.Deserialize<Yes_No>(responseBody);
    Console.WriteLine($"{t.answer} {t.forced} {t.image}");
}
catch (HttpRequestException e)
{
    Console.WriteLine("\nException Caught!");
    Console.WriteLine("Message :{0} ", e.Message);
}



