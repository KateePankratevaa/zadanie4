﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeroVsMonster.Classes
{
    /// <summary>
    /// Герой!
    /// Имеет два зелья. Может носить оружие. 
    /// Имеет способность, позволяющую добить противника, нанеся 
    /// десятикратный урон.
    /// </summary>
    public class Hero : Actor
    {
        /// <summary>
        /// Оружие, которое использует герой для победы.
        /// Если null, то герой бьет своим базовым уроном.
        /// </summary>
        public Weapon HeroWeapon { get; set; }

        
        public Hero(string name, int maximumHp, int damage) 
            : base(name, maximumHp, damage)
        {
            // вызывается конструктор базового класса
            // однако, у героя должно быть 2 зелья
        }

        /// <summary>
        /// Атакует врага. Если у героя есть оружие, то 
        /// наносится урон, равный урону оружия.
        /// Если оружия нет, то наносится базовый урон.
        /// </summary>
        /// <param name="enemy">Враг, которого нужно победить</param>
        public void Attack(Actor enemy)
        {
            throw new NotImplementedException("Не реализовано");
        }

        /// <summary>
        /// Добивает врага. Если враг имеет 1/5 здоровья
        /// или менее, то наносит десятикратный урон.
        /// В противном случае наносит обычный урон.
        /// </summary>
        /// <param name="enemy"></param>
        public void Execute(Actor enemy)
        {
            throw new NotImplementedException("Не реализовано");
        }

        /// <summary>
        /// Боевой крик героя! УУООООО!!!!
        /// </summary>
        /// <returns>Возвращает строку, соответствующую боевому крику</returns>
        public override string Roar()
        {
            return base.Roar();
        }

    }
}
