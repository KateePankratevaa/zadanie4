﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeroVsMonster.Classes
{
    /// <summary>
    /// Оружие. Используется героем для победы над врагами.
    /// </summary>
    public class Weapon
    {
        public int Damage { get; private set; }
        public Weapon(int damage)
        {
            this.Damage = damage;
        }
    }
}
