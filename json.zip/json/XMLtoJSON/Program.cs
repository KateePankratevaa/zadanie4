﻿using System.Text.Json;
using System.Xml.Linq;
//Задание 1.
XDocument doc = XDocument.Load("valutes.xml");

var valutes = doc.Element("ValCurs")
               .Elements("Valute")
               .Select(valute => new Valute
               {
                   Name = valute.Element("Name").Value,
                   CharCode = valute.Element("CharCode").Value,
                   Code = int.Parse(valute.Element("NumCode").Value),
                   Nominal = int.Parse(valute.Element("Nominal").Value),
                   Value = double.Parse(valute.Element("Value").Value)
               }).ToList();


valutes.Add(new Valute { Name = "Русский рубль", CharCode = "RUB", Code = 643, Nominal = 1, Value = 1 });

var options = new JsonSerializerOptions
{
    Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    WriteIndented = true
};
Console.WriteLine(JsonSerializer.Serialize(valutes, options));

//Задание 2.
for (int i = 0; i < 3; i++)
{

    HttpClient jk = new HttpClient();
    var response = await jk.GetAsync("https://catfact.ninja/fact");
    var cat_fact = await response.Content.ReadAsStringAsync();
    Cat p = JsonSerializer.Deserialize<Cat>(cat_fact);
    Console.WriteLine(p.fact);
    Console.WriteLine();
}



public class Cat
{
    public string fact { get; set; }
    public string lenght { get; set; }

}

internal class Valute
{
    public string Name { get; set; }
    public string CharCode { get; set; }
    public int Code { get; set; }
    public int Nominal { get; set; }
    public double Value { get; set; }
}
