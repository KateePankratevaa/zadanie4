﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using WPF_ValuteConverter.Models;

namespace WPF_ValuteConverter.Data
{
    public static class ValuteLoader
    {
  
        public static List<Valute> LoadValutes(string XMLText)
        {
            XDocument doc = XDocument.Parse(XMLText);

            var valutes = doc.Element("ValCurs")
                .Elements("Valute")
                .Select(valute => new Valute { 
                    Name = valute.Element("Name").Value, 
                    CharCode = valute.Element("CharCode").Value,
                    Code=int.Parse(valute.Element("NumCode").Value),
                    Nominal=int.Parse(valute.Element("Nominal").Value),
                    Value = double.Parse(valute.Element("Value").Value)
                }).ToList();
            valutes.Add(new Valute { Name = "Русский рубль", CharCode = "RUB", Code = 643, Nominal = 1,Value=1 });
            return valutes;
        }
    }
}
